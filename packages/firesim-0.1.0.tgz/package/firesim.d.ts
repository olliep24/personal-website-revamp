/* tslint:disable */
/* eslint-disable */

export function run_web(): void;
