/* @ts-self-types="./firesim.d.ts" */

import * as wasm from "./firesim_bg.wasm";
import { __wbg_set_wasm } from "./firesim_bg.js";
__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    run_web
} from "./firesim_bg.js";
